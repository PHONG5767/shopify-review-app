import styled from "styled-components";
const Bgcolorprocess = styled.div`
  position: relative;
  background-color: #d9d9d9;
  height: 8px;
  margin-right: 8px;
  color: #000;
  margin-left:8px;
  width: 60%;
  max-width: 82px;
  border-radius: 4px;
  &:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    background-color: #ffc107; 
    width:${props => props.ratingWidth};
    border-radius: 4px;
  }
`;
export default function ProcessRating({ numberReview1, totalReview }) {
    return (
        <div>
            <div className="flex min-w-40 flex-row items-center justify-between">
                <div className="flex flex-row items-center">
                    <div className="mr-1 font-bold">5</div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <path d="M6.5 10.4479L10.517 13L9.451 8.19L13 4.95368L8.3265 4.53632L6.5 0L4.6735 4.53632L0 4.95368L3.549 8.19L2.483 13L6.5 10.4479Z" fill="#F29D38" />
                        </svg>
                    </div>
                </div>
                <Bgcolorprocess ratingWidth={`${numberReview1 / totalReview * 100}%`}></Bgcolorprocess>
                <div className="font-bold">({numberReview1})</div>
            </div>
            <div className="flex min-w-40 flex-row items-center justify-between">
                <div className="flex flex-row items-center">
                    <div className="mr-1 font-bold">4</div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <path d="M6.5 10.4479L10.517 13L9.451 8.19L13 4.95368L8.3265 4.53632L6.5 0L4.6735 4.53632L0 4.95368L3.549 8.19L2.483 13L6.5 10.4479Z" fill="#F29D38" />
                        </svg>
                    </div>
                </div>
                <Bgcolorprocess ratingWidth={`${numberReview1 / totalReview * 100}%`}></Bgcolorprocess>
                <div className="font-bold">({numberReview1})</div>
            </div>
            <div className="flex min-w-40 flex-row items-center justify-between">
                <div className="flex flex-row items-center">
                    <div className="mr-1 font-bold">3</div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <path d="M6.5 10.4479L10.517 13L9.451 8.19L13 4.95368L8.3265 4.53632L6.5 0L4.6735 4.53632L0 4.95368L3.549 8.19L2.483 13L6.5 10.4479Z" fill="#F29D38" />
                        </svg>
                    </div>
                </div>
                <Bgcolorprocess ratingWidth={`${numberReview1 / totalReview * 100}%`}></Bgcolorprocess>
                <div className="font-bold">({numberReview1})</div>
            </div>
            <div className="flex min-w-40 flex-row items-center justify-between">
                <div className="flex flex-row items-center">
                    <div className="mr-1 font-bold">2</div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <path d="M6.5 10.4479L10.517 13L9.451 8.19L13 4.95368L8.3265 4.53632L6.5 0L4.6735 4.53632L0 4.95368L3.549 8.19L2.483 13L6.5 10.4479Z" fill="#F29D38" />
                        </svg>
                    </div>
                </div>
                <Bgcolorprocess ratingWidth={`${numberReview1 / totalReview * 100}%`}></Bgcolorprocess>
                <div className="font-bold">({numberReview1})</div>
            </div>
            <div className="flex min-w-40 flex-row items-center justify-between">
                <div className="flex flex-row items-center">
                    <div className="mr-1 font-bold">1</div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                            <path d="M6.5 10.4479L10.517 13L9.451 8.19L13 4.95368L8.3265 4.53632L6.5 0L4.6735 4.53632L0 4.95368L3.549 8.19L2.483 13L6.5 10.4479Z" fill="#F29D38" />
                        </svg>
                    </div>
                </div>
                <Bgcolorprocess ratingWidth={`${numberReview1 / totalReview * 100}%`}></Bgcolorprocess>
                <div className="font-bold">({numberReview1})</div>
            </div>
        </div>
    )
}